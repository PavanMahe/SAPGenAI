/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["socialui/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
