sap.ui.define([
	"socialui/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
